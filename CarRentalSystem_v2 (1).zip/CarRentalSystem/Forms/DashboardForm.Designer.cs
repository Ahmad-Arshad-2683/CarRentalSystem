namespace CarRentalSystem.Forms
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlSidebar  = new Panel();
            lblBrand    = new Label();
            btnCustomer = new Button();
            btnCar      = new Button();
            btnRental   = new Button();
            pnlContent  = new Panel();
            pnlSidebar.SuspendLayout();
            SuspendLayout();

            // pnlSidebar
            pnlSidebar.BackColor = Color.FromArgb(21, 28, 43);
            pnlSidebar.Controls.Add(lblBrand);
            pnlSidebar.Controls.Add(btnCustomer);
            pnlSidebar.Controls.Add(btnCar);
            pnlSidebar.Controls.Add(btnRental);
            pnlSidebar.Dock = DockStyle.Left;
            pnlSidebar.Width = 150;

            // lblBrand
            lblBrand.ForeColor = Color.FromArgb(0, 188, 212);
            lblBrand.Font = new Font("Arial", 11, FontStyle.Bold);
            lblBrand.Location = new Point(5, 20);
            lblBrand.Size = new Size(140, 40);
            lblBrand.Text = "🚗 Car Rental";
            lblBrand.TextAlign = ContentAlignment.MiddleCenter;

            // btnCustomer
            SetupSideBtn(btnCustomer, "👤  Customer", 80);
            btnCustomer.Click += btnCustomer_Click;

            // btnCar
            SetupSideBtn(btnCar, "🚙  Car", 130);
            btnCar.Click += btnCar_Click;

            // btnRental
            SetupSideBtn(btnRental, "📋  Rental", 180);
            btnRental.Click += btnRental_Click;

            // pnlContent
            pnlContent.BackColor = Color.FromArgb(240, 242, 245);
            pnlContent.Dock = DockStyle.Fill;

            // DashboardForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 680);
            Controls.Add(pnlContent);
            Controls.Add(pnlSidebar);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Car Rental System";

            pnlSidebar.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void SetupSideBtn(Button btn, string text, int top)
        {
            btn.BackColor = Color.FromArgb(21, 28, 43);
            btn.FlatStyle = FlatStyle.Flat;
            btn.ForeColor = Color.White;
            btn.Font = new Font("Arial", 10);
            btn.Location = new Point(5, top);
            btn.Size = new Size(140, 40);
            btn.Text = text;
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.Padding = new Padding(8, 0, 0, 0);
            btn.Cursor = Cursors.Hand;
            btn.FlatAppearance.BorderSize = 0;
        }

        private Panel  pnlSidebar;
        private Panel  pnlContent;
        private Label  lblBrand;
        private Button btnCustomer;
        private Button btnCar;
        private Button btnRental;
    }
}
