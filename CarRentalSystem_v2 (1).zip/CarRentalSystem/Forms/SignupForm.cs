using CarRentalSystem.Database;

namespace CarRentalSystem.Forms
{
    public class SignupForm : Form
    {
        private TextBox txtUsername = new TextBox();
        private TextBox txtPassword = new TextBox();
        private TextBox txtConfirm  = new TextBox();

        public SignupForm()
        {
            Text = "Car Rental System — Signup";
            Size = new Size(400, 300);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Label lbl1 = new Label { Text = "Username:", Location = new Point(20, 30), AutoSize = true, Font = new Font("Arial", 10, FontStyle.Bold) };
            txtUsername.Location = new Point(130, 27); txtUsername.Size = new Size(220, 25); txtUsername.BorderStyle = BorderStyle.FixedSingle;

            Label lbl2 = new Label { Text = "Password:", Location = new Point(20, 75), AutoSize = true, Font = new Font("Arial", 10, FontStyle.Bold) };
            txtPassword.Location = new Point(130, 72); txtPassword.Size = new Size(220, 25); txtPassword.UseSystemPasswordChar = true; txtPassword.BorderStyle = BorderStyle.FixedSingle;

            Label lbl3 = new Label { Text = "Confirm:", Location = new Point(20, 120), AutoSize = true, Font = new Font("Arial", 10, FontStyle.Bold) };
            txtConfirm.Location = new Point(130, 117); txtConfirm.Size = new Size(220, 25); txtConfirm.UseSystemPasswordChar = true; txtConfirm.BorderStyle = BorderStyle.FixedSingle;

            Button btnRegister = new Button
            {
                Text = "REGISTER", Location = new Point(130, 170), Size = new Size(120, 35),
                BackColor = Color.DodgerBlue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = new Font("Arial", 9, FontStyle.Bold)
            };
            btnRegister.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
                { MessageBox.Show("All fields are required!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (txtPassword.Text != txtConfirm.Text)
                { MessageBox.Show("Passwords do not match!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (UserRepository.AddUser(txtUsername.Text.Trim(), txtPassword.Text.Trim()))
                { MessageBox.Show("Registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); Close(); }
                else
                { MessageBox.Show("Username already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };

            Controls.AddRange(new Control[] { lbl1, txtUsername, lbl2, txtPassword, lbl3, txtConfirm, btnRegister });
        }
    }
}
