namespace CarRentalSystem.Forms
{
    public partial class DashboardForm : Form
    {
        private Button? activeBtn;

        public DashboardForm()
        {
            InitializeComponent();
            ShowPanel(new CustomerForm(), btnCustomer);
        }

        private void ShowPanel(Form form, Button btn)
        {
            if (activeBtn != null)
                activeBtn.BackColor = Color.FromArgb(21, 28, 43);

            activeBtn = btn;
            btn.BackColor = Color.DodgerBlue;

            pnlContent.Controls.Clear();
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            pnlContent.Controls.Add(form);
            form.Show();
        }

        private void btnCustomer_Click(object sender, EventArgs e) => ShowPanel(new CustomerForm(), btnCustomer);
        private void btnCar_Click(object sender, EventArgs e)      => ShowPanel(new CarForm(), btnCar);
        private void btnRental_Click(object sender, EventArgs e)   => ShowPanel(new RentalForm(), btnRental);
    }
}
