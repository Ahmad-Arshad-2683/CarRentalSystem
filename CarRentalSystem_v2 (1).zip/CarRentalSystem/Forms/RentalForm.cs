using CarRentalSystem.Database;
using CarRentalSystem.Models;

namespace CarRentalSystem.Forms
{
    public partial class RentalForm : Form
    {
        private int selectedId = -1;

        public RentalForm()
        {
            InitializeComponent();
            LoadCarNumbers();
            LoadRentals();
        }

        private void LoadCarNumbers()
        {
            cmbCarNumber.Items.Clear();
            foreach (string num in CarRepository.GetCarNumbers())
                cmbCarNumber.Items.Add(num);
            if (cmbCarNumber.Items.Count > 0)
                cmbCarNumber.SelectedIndex = 0;
        }

        private void LoadRentals()
        {
            dgvRentals.Rows.Clear();
            dgvRentals.Columns.Clear();

            dgvRentals.Columns.Add("Id",           "ID");
            dgvRentals.Columns.Add("RentalID",     "Rental_ID");
            dgvRentals.Columns.Add("CustomerName", "Customer Name");
            dgvRentals.Columns.Add("CarNumber",    "Car Number");
            dgvRentals.Columns.Add("StartDate",    "Start Date");
            dgvRentals.Columns.Add("EndDate",      "End Date");
            dgvRentals.Columns.Add("Total",        "Total (PKR)");

            dgvRentals.Columns["Id"].Visible = false;

            foreach (Rental r in RentalRepository.GetAll())
                dgvRentals.Rows.Add(r.Id, r.Id, r.CustomerName, r.CarNumber, r.StartDate, r.EndDate, r.Total);
        }

        private void CalculateTotal()
        {
            try
            {
                if (dtpStartDate.Value >= dtpEndDate.Value) { txtTotal.Text = "0"; return; }
                int days = (dtpEndDate.Value - dtpStartDate.Value).Days;
                string? carNum = cmbCarNumber.SelectedItem?.ToString();
                Car? car = CarRepository.GetAll().FirstOrDefault(c => c.CarNumber == carNum);
                txtTotal.Text = car != null ? (days * car.RentPrice).ToString("F2") : "0";
            }
            catch { txtTotal.Text = "0"; }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            selectedId = -1;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomerName.Text) || cmbCarNumber.SelectedItem == null)
            {
                MessageBox.Show("Customer Name and Car Number are required!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Rental r = new Rental
            {
                Id           = selectedId,
                CustomerName = txtCustomerName.Text.Trim(),
                CarNumber    = cmbCarNumber.SelectedItem.ToString()!,
                StartDate    = dtpStartDate.Value.ToString("yyyy-MM-dd"),
                EndDate      = dtpEndDate.Value.ToString("yyyy-MM-dd"),
                Total        = double.TryParse(txtTotal.Text, out double t) ? t : 0
            };

            bool ok = selectedId == -1 ? RentalRepository.Add(r) : RentalRepository.Update(r);
            if (ok)
            {
                MessageBox.Show("Saved successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                LoadRentals();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1)
            {
                MessageBox.Show("Please select a rental to delete!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this rental?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (RentalRepository.Delete(selectedId))
                {
                    MessageBox.Show("Deleted successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields();
                    LoadRentals();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e) => ClearFields();

        private void dgvRentals_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = dgvRentals.Rows[e.RowIndex];
            selectedId              = int.Parse(row.Cells["Id"].Value.ToString()!);
            txtRentalId.Text        = row.Cells["RentalID"].Value.ToString();
            txtCustomerName.Text    = row.Cells["CustomerName"].Value.ToString();
            cmbCarNumber.SelectedItem = row.Cells["CarNumber"].Value.ToString();
            if (DateTime.TryParse(row.Cells["StartDate"].Value.ToString(), out DateTime s)) dtpStartDate.Value = s;
            if (DateTime.TryParse(row.Cells["EndDate"].Value.ToString(), out DateTime en)) dtpEndDate.Value = en;
            txtTotal.Text           = row.Cells["Total"].Value.ToString();
        }

        private void dtpStartDate_ValueChanged(object sender, EventArgs e) => CalculateTotal();
        private void dtpEndDate_ValueChanged(object sender, EventArgs e)   => CalculateTotal();
        private void cmbCarNumber_SelectedIndexChanged(object sender, EventArgs e) => CalculateTotal();

        private void ClearFields()
        {
            txtRentalId.Clear();
            txtCustomerName.Clear();
            txtTotal.Clear();
            dtpStartDate.Value = DateTime.Today;
            dtpEndDate.Value   = DateTime.Today.AddDays(1);
            if (cmbCarNumber.Items.Count > 0) cmbCarNumber.SelectedIndex = 0;
            selectedId = -1;
        }
    }
}
