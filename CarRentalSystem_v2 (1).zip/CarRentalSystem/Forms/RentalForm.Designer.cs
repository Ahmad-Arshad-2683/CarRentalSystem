namespace CarRentalSystem.Forms
{
    partial class RentalForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlHeader       = new Panel();
            lblHeader       = new Label();
            pnlFields       = new Panel();
            lblRentalId     = new Label();
            txtRentalId     = new TextBox();
            lblCustomerName = new Label();
            txtCustomerName = new TextBox();
            lblCarNumber    = new Label();
            cmbCarNumber    = new ComboBox();
            lblStartDate    = new Label();
            dtpStartDate    = new DateTimePicker();
            lblEndDate      = new Label();
            dtpEndDate      = new DateTimePicker();
            lblTotal        = new Label();
            txtTotal        = new TextBox();
            btnSave         = new Button();
            btnAdd          = new Button();
            btnDelete       = new Button();
            btnClear        = new Button();
            dgvRentals      = new DataGridView();
            pnlHeader.SuspendLayout();
            pnlFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvRentals).BeginInit();
            SuspendLayout();

            // pnlHeader
            pnlHeader.BackColor = Color.DodgerBlue;
            pnlHeader.Controls.Add(lblHeader);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 55;

            // lblHeader
            lblHeader.Dock = DockStyle.Fill;
            lblHeader.Font = new Font("Arial", 16, FontStyle.Bold);
            lblHeader.ForeColor = Color.White;
            lblHeader.Text = "MANAGE RENTAL";
            lblHeader.TextAlign = ContentAlignment.MiddleCenter;

            // pnlFields
            pnlFields.BackColor = Color.White;
            pnlFields.Location = new Point(20, 70);
            pnlFields.Size = new Size(500, 280);

            SetLabel(lblRentalId,     "Rental_ID",     20, 20);
            SetTextBox(txtRentalId,               160, 20); txtRentalId.ReadOnly = true; txtRentalId.BackColor = Color.WhiteSmoke;
            SetLabel(lblCustomerName, "Customer Name", 20, 65);
            SetTextBox(txtCustomerName,           160, 65);
            SetLabel(lblCarNumber,    "Car Number",    20, 110);
            cmbCarNumber.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCarNumber.Font = new Font("Arial", 10);
            cmbCarNumber.Location = new Point(160, 110);
            cmbCarNumber.Size = new Size(200, 25);
            cmbCarNumber.SelectedIndexChanged += cmbCarNumber_SelectedIndexChanged;
            SetLabel(lblStartDate,    "Start Date",    20, 155);
            dtpStartDate.Font = new Font("Arial", 10);
            dtpStartDate.Location = new Point(160, 155);
            dtpStartDate.Size = new Size(200, 25);
            dtpStartDate.Format = DateTimePickerFormat.Short;
            dtpStartDate.ValueChanged += dtpStartDate_ValueChanged;
            SetLabel(lblEndDate,      "End Date",      20, 200);
            dtpEndDate.Font = new Font("Arial", 10);
            dtpEndDate.Location = new Point(160, 200);
            dtpEndDate.Size = new Size(200, 25);
            dtpEndDate.Format = DateTimePickerFormat.Short;
            dtpEndDate.Value = DateTime.Today.AddDays(1);
            dtpEndDate.ValueChanged += dtpEndDate_ValueChanged;
            SetLabel(lblTotal,        "Total (PKR)",   20, 245);
            SetTextBox(txtTotal,                  160, 245); txtTotal.ReadOnly = true; txtTotal.BackColor = Color.WhiteSmoke;

            pnlFields.Controls.AddRange(new Control[] {
                lblRentalId, txtRentalId,
                lblCustomerName, txtCustomerName,
                lblCarNumber, cmbCarNumber,
                lblStartDate, dtpStartDate,
                lblEndDate, dtpEndDate,
                lblTotal, txtTotal
            });

            // Buttons
            SetButton(btnSave,   "💾 Save",   Color.Green,      20, 365); btnSave.Click   += btnSave_Click;
            SetButton(btnAdd,    "➕ Add",    Color.DodgerBlue, 130, 365); btnAdd.Click    += btnAdd_Click;
            SetButton(btnDelete, "🗑️ Delete", Color.Red,        240, 365); btnDelete.Click += btnDelete_Click;
            SetButton(btnClear,  "🔄 Clear",  Color.Gray,       350, 365); btnClear.Click  += btnClear_Click;

            // dgvRentals
            dgvRentals.AllowUserToAddRows = false;
            dgvRentals.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRentals.BackgroundColor = Color.White;
            dgvRentals.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(21, 28, 43);
            dgvRentals.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvRentals.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvRentals.Location = new Point(20, 415);
            dgvRentals.ReadOnly = true;
            dgvRentals.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRentals.Size = new Size(1000, 220);
            dgvRentals.CellClick += dgvRentals_CellClick;

            // RentalForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 242, 245);
            ClientSize = new Size(1050, 660);
            Controls.Add(pnlHeader);
            Controls.Add(pnlFields);
            Controls.Add(btnSave);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(btnClear);
            Controls.Add(dgvRentals);
            Text = "Car Rental System — Rental";

            pnlHeader.ResumeLayout(false);
            pnlFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvRentals).EndInit();
            ResumeLayout(false);
        }

        private void SetLabel(Label l, string text, int x, int y)
        {
            l.AutoSize = true; l.Font = new Font("Arial", 10, FontStyle.Bold);
            l.Location = new Point(x, y); l.Text = text;
        }
        private void SetTextBox(TextBox t, int x, int y)
        {
            t.BorderStyle = BorderStyle.FixedSingle; t.Font = new Font("Arial", 10);
            t.Location = new Point(x, y); t.Size = new Size(200, 25);
        }
        private void SetButton(Button b, string text, Color color, int x, int y)
        {
            b.BackColor = color; b.FlatStyle = FlatStyle.Flat;
            b.Font = new Font("Arial", 9, FontStyle.Bold); b.ForeColor = Color.White;
            b.Location = new Point(x, y); b.Size = new Size(100, 35); b.Text = text;
        }

        private Panel          pnlHeader;
        private Label          lblHeader;
        private Panel          pnlFields;
        private Label          lblRentalId;
        private TextBox        txtRentalId;
        private Label          lblCustomerName;
        private TextBox        txtCustomerName;
        private Label          lblCarNumber;
        private ComboBox       cmbCarNumber;
        private Label          lblStartDate;
        private DateTimePicker dtpStartDate;
        private Label          lblEndDate;
        private DateTimePicker dtpEndDate;
        private Label          lblTotal;
        private TextBox        txtTotal;
        private Button         btnSave;
        private Button         btnAdd;
        private Button         btnDelete;
        private Button         btnClear;
        private DataGridView   dgvRentals;
    }
}
