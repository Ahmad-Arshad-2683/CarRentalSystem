using CarRentalSystem.Database;
using CarRentalSystem.Models;

namespace CarRentalSystem.Forms
{
    public partial class CarForm : Form
    {
        private int selectedId = -1;

        public CarForm()
        {
            InitializeComponent();
            LoadCars();
        }

        private void LoadCars()
        {
            dgvCars.Rows.Clear();
            dgvCars.Columns.Clear();

            dgvCars.Columns.Add("Id",        "ID");
            dgvCars.Columns.Add("CarID",     "Car_ID");
            dgvCars.Columns.Add("CarName",   "Car Name");
            dgvCars.Columns.Add("RentPrice", "Rent Price");
            dgvCars.Columns.Add("CarNumber", "Car Number");

            dgvCars.Columns["Id"].Visible = false;

            foreach (Car c in CarRepository.GetAll())
                dgvCars.Rows.Add(c.Id, c.Id, c.CarName, c.RentPrice, c.CarNumber);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            selectedId = -1;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCarName.Text) || string.IsNullOrWhiteSpace(txtCarNumber.Text))
            {
                MessageBox.Show("Car Name and Car Number are required!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!double.TryParse(txtRentPrice.Text, out double price))
            {
                MessageBox.Show("Please enter a valid Rent Price!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Car c = new Car
            {
                Id        = selectedId,
                CarName   = txtCarName.Text.Trim(),
                RentPrice = price,
                CarNumber = txtCarNumber.Text.Trim()
            };

            bool ok = selectedId == -1 ? CarRepository.Add(c) : CarRepository.Update(c);
            if (ok)
            {
                MessageBox.Show("Saved successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                LoadCars();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1)
            {
                MessageBox.Show("Please select a car to delete!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this car?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (CarRepository.Delete(selectedId))
                {
                    MessageBox.Show("Deleted successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields();
                    LoadCars();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void dgvCars_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = dgvCars.Rows[e.RowIndex];
            selectedId          = int.Parse(row.Cells["Id"].Value.ToString()!);
            txtCarId.Text       = row.Cells["CarID"].Value.ToString();
            txtCarName.Text     = row.Cells["CarName"].Value.ToString();
            txtRentPrice.Text   = row.Cells["RentPrice"].Value.ToString();
            txtCarNumber.Text   = row.Cells["CarNumber"].Value.ToString();
        }

        private void ClearFields()
        {
            txtCarId.Clear();
            txtCarName.Clear();
            txtRentPrice.Clear();
            txtCarNumber.Clear();
            selectedId = -1;
        }
    }
}
