namespace CarRentalSystem.Forms
{
    partial class CustomerForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlHeader       = new Panel();
            lblHeader       = new Label();
            pnlFields       = new Panel();
            lblCustomerId   = new Label();
            txtCustomerId   = new TextBox();
            lblCustomerName = new Label();
            txtCustomerName = new TextBox();
            lblPhoneNumber  = new Label();
            txtPhoneNumber  = new TextBox();
            lblAddress      = new Label();
            txtAddress      = new TextBox();
            btnSave         = new Button();
            btnAdd          = new Button();
            btnDelete       = new Button();
            dgvCustomers    = new DataGridView();
            pnlHeader.SuspendLayout();
            pnlFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).BeginInit();
            SuspendLayout();

            // pnlHeader
            pnlHeader.BackColor = Color.DodgerBlue;
            pnlHeader.Controls.Add(lblHeader);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 55;

            // lblHeader
            lblHeader.Dock = DockStyle.Fill;
            lblHeader.Font = new Font("Arial", 16, FontStyle.Bold);
            lblHeader.ForeColor = Color.White;
            lblHeader.Text = "MANAGE CUSTOMER";
            lblHeader.TextAlign = ContentAlignment.MiddleCenter;

            // pnlFields
            pnlFields.BackColor = Color.White;
            pnlFields.Location = new Point(20, 70);
            pnlFields.Size = new Size(500, 220);

            SetLabel(lblCustomerId,   "Customer_ID",   20, 20);
            SetTextBox(txtCustomerId,               160, 20); txtCustomerId.ReadOnly = true; txtCustomerId.BackColor = Color.WhiteSmoke;
            SetLabel(lblCustomerName, "Customer Name", 20, 65);
            SetTextBox(txtCustomerName,             160, 65);
            SetLabel(lblPhoneNumber,  "Phone Number",  20, 110);
            SetTextBox(txtPhoneNumber,              160, 110);
            SetLabel(lblAddress,      "Address",       20, 155);
            SetTextBox(txtAddress,                  160, 155);

            pnlFields.Controls.AddRange(new Control[] {
                lblCustomerId, txtCustomerId,
                lblCustomerName, txtCustomerName,
                lblPhoneNumber, txtPhoneNumber,
                lblAddress, txtAddress
            });

            // Buttons
            SetButton(btnSave,   "💾 Save",   Color.Green,      20, 305); btnSave.Click   += btnSave_Click;
            SetButton(btnAdd,    "➕ Add",    Color.DodgerBlue, 130, 305); btnAdd.Click    += btnAdd_Click;
            SetButton(btnDelete, "🗑️ Delete", Color.Red,        240, 305); btnDelete.Click += btnDelete_Click;

            // dgvCustomers
            dgvCustomers.AllowUserToAddRows = false;
            dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCustomers.BackgroundColor = Color.White;
            dgvCustomers.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(21, 28, 43);
            dgvCustomers.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvCustomers.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvCustomers.Location = new Point(20, 355);
            dgvCustomers.ReadOnly = true;
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.Size = new Size(1000, 280);
            dgvCustomers.CellClick += dgvCustomers_CellClick;

            // CustomerForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 242, 245);
            ClientSize = new Size(1050, 660);
            Controls.Add(pnlHeader);
            Controls.Add(pnlFields);
            Controls.Add(btnSave);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(dgvCustomers);
            Text = "Car Rental System — Customer";

            pnlHeader.ResumeLayout(false);
            pnlFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).EndInit();
            ResumeLayout(false);
        }

        private void SetLabel(Label l, string text, int x, int y)
        {
            l.AutoSize = true; l.Font = new Font("Arial", 10, FontStyle.Bold);
            l.Location = new Point(x, y); l.Text = text;
        }
        private void SetTextBox(TextBox t, int x, int y)
        {
            t.BorderStyle = BorderStyle.FixedSingle; t.Font = new Font("Arial", 10);
            t.Location = new Point(x, y); t.Size = new Size(200, 25);
        }
        private void SetButton(Button b, string text, Color color, int x, int y)
        {
            b.BackColor = color; b.FlatStyle = FlatStyle.Flat;
            b.Font = new Font("Arial", 9, FontStyle.Bold); b.ForeColor = Color.White;
            b.Location = new Point(x, y); b.Size = new Size(100, 35); b.Text = text;
        }

        private Panel           pnlHeader;
        private Label           lblHeader;
        private Panel           pnlFields;
        private Label           lblCustomerId;
        private TextBox         txtCustomerId;
        private Label           lblCustomerName;
        private TextBox         txtCustomerName;
        private Label           lblPhoneNumber;
        private TextBox         txtPhoneNumber;
        private Label           lblAddress;
        private TextBox         txtAddress;
        private Button          btnSave;
        private Button          btnAdd;
        private Button          btnDelete;
        private DataGridView    dgvCustomers;
    }
}
