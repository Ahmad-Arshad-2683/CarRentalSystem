using CarRentalSystem.Database;
using CarRentalSystem.Models;

namespace CarRentalSystem.Forms
{
    public partial class CustomerForm : Form
    {
        private int selectedId = -1;

        public CustomerForm()
        {
            InitializeComponent();
            LoadCustomers();
        }

        private void LoadCustomers()
        {
            dgvCustomers.Rows.Clear();
            dgvCustomers.Columns.Clear();

            dgvCustomers.Columns.Add("Id",           "ID");
            dgvCustomers.Columns.Add("CustomerID",   "Customer_ID");
            dgvCustomers.Columns.Add("Name",         "Name");
            dgvCustomers.Columns.Add("PhoneNumber",  "Phone Number");
            dgvCustomers.Columns.Add("Address",      "Address");

            dgvCustomers.Columns["Id"].Visible = false;

            foreach (Customer c in CustomerRepository.GetAll())
                dgvCustomers.Rows.Add(c.Id, c.Id, c.CustomerName, c.PhoneNumber, c.Address);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            selectedId = -1;
            MessageBox.Show("Fields cleared. Fill in and click Save.", "Add",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
            {
                MessageBox.Show("Customer Name is required!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Customer c = new Customer
            {
                Id           = selectedId,
                CustomerName = txtCustomerName.Text.Trim(),
                PhoneNumber  = txtPhoneNumber.Text.Trim(),
                Address      = txtAddress.Text.Trim()
            };

            bool ok = selectedId == -1 ? CustomerRepository.Add(c) : CustomerRepository.Update(c);
            if (ok)
            {
                MessageBox.Show("Saved successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                LoadCustomers();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == -1)
            {
                MessageBox.Show("Please select a customer to delete!", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this customer?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (CustomerRepository.Delete(selectedId))
                {
                    MessageBox.Show("Deleted successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields();
                    LoadCustomers();
                }
            }
        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = dgvCustomers.Rows[e.RowIndex];
            selectedId              = int.Parse(row.Cells["Id"].Value.ToString()!);
            txtCustomerId.Text      = row.Cells["CustomerID"].Value.ToString();
            txtCustomerName.Text    = row.Cells["Name"].Value.ToString();
            txtPhoneNumber.Text     = row.Cells["PhoneNumber"].Value.ToString();
            txtAddress.Text         = row.Cells["Address"].Value.ToString();
        }

        private void ClearFields()
        {
            txtCustomerId.Clear();
            txtCustomerName.Clear();
            txtPhoneNumber.Clear();
            txtAddress.Clear();
            selectedId = -1;
        }
    }
}
