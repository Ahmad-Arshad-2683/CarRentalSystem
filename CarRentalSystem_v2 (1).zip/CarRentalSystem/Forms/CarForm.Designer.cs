namespace CarRentalSystem.Forms
{
    partial class CarForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlHeader    = new Panel();
            lblHeader    = new Label();
            pnlFields    = new Panel();
            lblCarId     = new Label();
            txtCarId     = new TextBox();
            lblCarName   = new Label();
            txtCarName   = new TextBox();
            lblRentPrice = new Label();
            txtRentPrice = new TextBox();
            lblCarNumber = new Label();
            txtCarNumber = new TextBox();
            btnSave      = new Button();
            btnAdd       = new Button();
            btnDelete    = new Button();
            btnClear     = new Button();
            dgvCars      = new DataGridView();
            pnlHeader.SuspendLayout();
            pnlFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCars).BeginInit();
            SuspendLayout();

            // pnlHeader
            pnlHeader.BackColor = Color.DodgerBlue;
            pnlHeader.Controls.Add(lblHeader);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 55;

            // lblHeader
            lblHeader.Dock = DockStyle.Fill;
            lblHeader.Font = new Font("Arial", 16, FontStyle.Bold);
            lblHeader.ForeColor = Color.White;
            lblHeader.Text = "MANAGE CARS";
            lblHeader.TextAlign = ContentAlignment.MiddleCenter;

            // pnlFields
            pnlFields.BackColor = Color.White;
            pnlFields.Location = new Point(20, 70);
            pnlFields.Size = new Size(500, 220);

            SetLabel(lblCarId,     "Car_ID",     20, 20);
            SetTextBox(txtCarId,              160, 20); txtCarId.ReadOnly = true; txtCarId.BackColor = Color.WhiteSmoke;
            SetLabel(lblCarName,   "Car Name",   20, 65);
            SetTextBox(txtCarName,            160, 65);
            SetLabel(lblRentPrice, "Rent Price", 20, 110);
            SetTextBox(txtRentPrice,          160, 110);
            SetLabel(lblCarNumber, "Car Number", 20, 155);
            SetTextBox(txtCarNumber,          160, 155);

            pnlFields.Controls.AddRange(new Control[] {
                lblCarId, txtCarId,
                lblCarName, txtCarName,
                lblRentPrice, txtRentPrice,
                lblCarNumber, txtCarNumber
            });

            // Buttons
            SetButton(btnSave,   "💾 Save",   Color.Green,      20, 305); btnSave.Click   += btnSave_Click;
            SetButton(btnAdd,    "➕ Add",    Color.DodgerBlue, 130, 305); btnAdd.Click    += btnAdd_Click;
            SetButton(btnDelete, "🗑️ Delete", Color.Red,        240, 305); btnDelete.Click += btnDelete_Click;
            SetButton(btnClear,  "🔄 Clear",  Color.Gray,       350, 305); btnClear.Click  += btnClear_Click;

            // dgvCars
            dgvCars.AllowUserToAddRows = false;
            dgvCars.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCars.BackgroundColor = Color.White;
            dgvCars.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(21, 28, 43);
            dgvCars.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvCars.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvCars.Location = new Point(20, 355);
            dgvCars.ReadOnly = true;
            dgvCars.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCars.Size = new Size(1000, 280);
            dgvCars.CellClick += dgvCars_CellClick;

            // CarForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 242, 245);
            ClientSize = new Size(1050, 660);
            Controls.Add(pnlHeader);
            Controls.Add(pnlFields);
            Controls.Add(btnSave);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(btnClear);
            Controls.Add(dgvCars);
            Text = "Car Rental System — Car";

            pnlHeader.ResumeLayout(false);
            pnlFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvCars).EndInit();
            ResumeLayout(false);
        }

        private void SetLabel(Label l, string text, int x, int y)
        {
            l.AutoSize = true; l.Font = new Font("Arial", 10, FontStyle.Bold);
            l.Location = new Point(x, y); l.Text = text;
        }
        private void SetTextBox(TextBox t, int x, int y)
        {
            t.BorderStyle = BorderStyle.FixedSingle; t.Font = new Font("Arial", 10);
            t.Location = new Point(x, y); t.Size = new Size(200, 25);
        }
        private void SetButton(Button b, string text, Color color, int x, int y)
        {
            b.BackColor = color; b.FlatStyle = FlatStyle.Flat;
            b.Font = new Font("Arial", 9, FontStyle.Bold); b.ForeColor = Color.White;
            b.Location = new Point(x, y); b.Size = new Size(100, 35); b.Text = text;
        }

        private Panel        pnlHeader;
        private Label        lblHeader;
        private Panel        pnlFields;
        private Label        lblCarId;
        private TextBox      txtCarId;
        private Label        lblCarName;
        private TextBox      txtCarName;
        private Label        lblRentPrice;
        private TextBox      txtRentPrice;
        private Label        lblCarNumber;
        private TextBox      txtCarNumber;
        private Button       btnSave;
        private Button       btnAdd;
        private Button       btnDelete;
        private Button       btnClear;
        private DataGridView dgvCars;
    }
}
