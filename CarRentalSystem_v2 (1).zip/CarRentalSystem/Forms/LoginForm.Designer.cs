namespace CarRentalSystem.Forms
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            pnlHeader      = new Panel();
            lblTitle       = new Label();
            txtUsername    = new TextBox();
            txtPassword    = new TextBox();
            lblUsername    = new Label();
            lblPassword    = new Label();
            chkShowPassword = new CheckBox();
            btnLogin       = new Button();
            btnSignup      = new Button();
            pnlUnderline   = new Panel();
            pnlHeader.SuspendLayout();
            SuspendLayout();

            // pnlHeader
            pnlHeader.BackColor = Color.FromArgb(184, 134, 11);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 80;

            // lblTitle
            lblTitle.Dock = DockStyle.Fill;
            lblTitle.Font = new Font("Arial", 20, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Text = "LOGIN FORM";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            // lblUsername
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Arial", 12, FontStyle.Bold);
            lblUsername.Location = new Point(310, 130);
            lblUsername.Text = "Username";

            // txtUsername
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.Font = new Font("Arial", 11);
            txtUsername.Location = new Point(310, 160);
            txtUsername.Size = new Size(380, 28);
            txtUsername.Name = "txtUsername";

            // pnlUnderline
            pnlUnderline.BackColor = Color.DodgerBlue;
            pnlUnderline.Location = new Point(310, 190);
            pnlUnderline.Size = new Size(380, 2);

            // lblPassword
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Arial", 12, FontStyle.Bold);
            lblPassword.Location = new Point(310, 215);
            lblPassword.Text = "Password";

            // txtPassword
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Arial", 11);
            txtPassword.Location = new Point(310, 245);
            txtPassword.Size = new Size(380, 28);
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.Name = "txtPassword";

            // chkShowPassword
            chkShowPassword.AutoSize = true;
            chkShowPassword.Location = new Point(545, 280);
            chkShowPassword.Text = "Show Password";
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChanged;

            // btnSignup
            btnSignup.BackColor = Color.Red;
            btnSignup.FlatStyle = FlatStyle.Flat;
            btnSignup.Font = new Font("Arial", 9, FontStyle.Bold);
            btnSignup.ForeColor = Color.White;
            btnSignup.Location = new Point(35, 560);
            btnSignup.Size = new Size(130, 38);
            btnSignup.Text = "SIGNUP NOW";
            btnSignup.Click += btnSignup_Click;

            // btnLogin
            btnLogin.BackColor = Color.Green;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Arial", 9, FontStyle.Bold);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(560, 560);
            btnLogin.Size = new Size(130, 38);
            btnLogin.Text = "LOGIN";
            btnLogin.Click += btnLogin_Click;

            // LoginForm
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(740, 630);
            Controls.Add(pnlHeader);
            Controls.Add(lblUsername);
            Controls.Add(txtUsername);
            Controls.Add(pnlUnderline);
            Controls.Add(lblPassword);
            Controls.Add(txtPassword);
            Controls.Add(chkShowPassword);
            Controls.Add(btnSignup);
            Controls.Add(btnLogin);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Car Rental System — Login";

            pnlHeader.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        private Panel   pnlHeader;
        private Label   lblTitle;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Label   lblUsername;
        private Label   lblPassword;
        private CheckBox chkShowPassword;
        private Button  btnLogin;
        private Button  btnSignup;
        private Panel   pnlUnderline;
    }
}
