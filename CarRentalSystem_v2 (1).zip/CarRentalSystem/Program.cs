using CarRentalSystem.Database;
using CarRentalSystem.Forms;

namespace CarRentalSystem;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        DatabaseHelper.InitializeDatabase();
        Application.Run(new LoginForm());
    }
}
