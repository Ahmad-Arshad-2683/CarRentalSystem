using System.Data.SQLite;

namespace CarRentalSystem.Database
{
    public class UserRepository
    {
        public static bool ValidateLogin(string username, string password)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "SELECT Password FROM Users WHERE Username=@u";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        string? hashedPassword = cmd.ExecuteScalar()?.ToString();
                        if (hashedPassword == null) return false;
                        return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
                    }
                }
            }
            catch { return false; }
        }

        public static bool AddUser(string username, string password)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string hash = BCrypt.Net.BCrypt.HashPassword(password);
                    string sql = "INSERT INTO Users (Username, Password) VALUES (@u, @p)";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@p", hash);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }
    }
}
