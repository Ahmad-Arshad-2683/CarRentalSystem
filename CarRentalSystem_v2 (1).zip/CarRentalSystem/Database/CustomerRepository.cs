using System.Data.SQLite;
using CarRentalSystem.Models;

namespace CarRentalSystem.Database
{
    public class CustomerRepository
    {
        public static List<Customer> GetAll()
        {
            List<Customer> list = new List<Customer>();
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("SELECT * FROM Customers", conn))
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            list.Add(new Customer
                            {
                                Id           = reader.GetInt32(0),
                                CustomerName = reader.GetString(1),
                                PhoneNumber  = reader[2].ToString() ?? "",
                                Address      = reader[3].ToString() ?? ""
                            });
                    }
                }
            }
            catch { }
            return list;
        }

        public static bool Add(Customer c)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "INSERT INTO Customers (CustomerName, PhoneNumber, Address) VALUES (@n, @p, @a)";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n", c.CustomerName);
                        cmd.Parameters.AddWithValue("@p", c.PhoneNumber);
                        cmd.Parameters.AddWithValue("@a", c.Address);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Update(Customer c)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "UPDATE Customers SET CustomerName=@n, PhoneNumber=@p, Address=@a WHERE Id=@id";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n", c.CustomerName);
                        cmd.Parameters.AddWithValue("@p", c.PhoneNumber);
                        cmd.Parameters.AddWithValue("@a", c.Address);
                        cmd.Parameters.AddWithValue("@id", c.Id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Delete(int id)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Customers WHERE Id=@id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }
    }
}
