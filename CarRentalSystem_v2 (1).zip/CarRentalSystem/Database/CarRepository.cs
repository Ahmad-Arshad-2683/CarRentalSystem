using System.Data.SQLite;
using CarRentalSystem.Models;

namespace CarRentalSystem.Database
{
    public class CarRepository
    {
        public static List<Car> GetAll()
        {
            List<Car> list = new List<Car>();
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("SELECT * FROM Cars", conn))
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            list.Add(new Car
                            {
                                Id        = reader.GetInt32(0),
                                CarName   = reader.GetString(1),
                                RentPrice = reader.GetDouble(2),
                                CarNumber = reader.GetString(3)
                            });
                    }
                }
            }
            catch { }
            return list;
        }

        public static bool Add(Car c)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "INSERT INTO Cars (CarName, RentPrice, CarNumber) VALUES (@n, @r, @c)";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n", c.CarName);
                        cmd.Parameters.AddWithValue("@r", c.RentPrice);
                        cmd.Parameters.AddWithValue("@c", c.CarNumber);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Update(Car c)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "UPDATE Cars SET CarName=@n, RentPrice=@r, CarNumber=@c WHERE Id=@id";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@n", c.CarName);
                        cmd.Parameters.AddWithValue("@r", c.RentPrice);
                        cmd.Parameters.AddWithValue("@c", c.CarNumber);
                        cmd.Parameters.AddWithValue("@id", c.Id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Delete(int id)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Cars WHERE Id=@id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static List<string> GetCarNumbers()
        {
            List<string> list = new List<string>();
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("SELECT CarNumber FROM Cars", conn))
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                        while (reader.Read()) list.Add(reader.GetString(0));
                }
            }
            catch { }
            return list;
        }
    }
}
