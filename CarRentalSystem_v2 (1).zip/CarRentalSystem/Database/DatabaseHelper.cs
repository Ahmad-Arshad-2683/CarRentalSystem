using System.Data.SQLite;

namespace CarRentalSystem.Database
{
    public class DatabaseHelper
    {
        private static string dbPath = "carrental.db";
        public static string ConnectionString = $"Data Source={dbPath};Version=3;";

        public static void InitializeDatabase()
        {
            try
            {
                if (!File.Exists(dbPath))
                    SQLiteConnection.CreateFile(dbPath);

                using (SQLiteConnection conn = new SQLiteConnection(ConnectionString))
                {
                    conn.Open();

                    string[] tables = {
                        @"CREATE TABLE IF NOT EXISTS Users (
                            Id       INTEGER PRIMARY KEY AUTOINCREMENT,
                            Username TEXT NOT NULL UNIQUE,
                            Password TEXT NOT NULL
                        );",
                        @"CREATE TABLE IF NOT EXISTS Customers (
                            Id          INTEGER PRIMARY KEY AUTOINCREMENT,
                            CustomerName TEXT NOT NULL,
                            PhoneNumber  TEXT,
                            Address      TEXT
                        );",
                        @"CREATE TABLE IF NOT EXISTS Cars (
                            Id         INTEGER PRIMARY KEY AUTOINCREMENT,
                            CarName    TEXT NOT NULL,
                            RentPrice  REAL NOT NULL DEFAULT 0,
                            CarNumber  TEXT NOT NULL UNIQUE
                        );",
                        @"CREATE TABLE IF NOT EXISTS Rentals (
                            Id           INTEGER PRIMARY KEY AUTOINCREMENT,
                            CustomerName TEXT NOT NULL,
                            CarNumber    TEXT NOT NULL,
                            StartDate    TEXT NOT NULL,
                            EndDate      TEXT NOT NULL,
                            Total        REAL NOT NULL DEFAULT 0
                        );"
                    };

                    foreach (string sql in tables)
                    {
                        using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                            cmd.ExecuteNonQuery();
                    }

                    string checkAdmin = "SELECT COUNT(*) FROM Users WHERE Username='admin'";
                    using (SQLiteCommand cmd = new SQLiteCommand(checkAdmin, conn))
                    {
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count == 0)
                        {
                            string hashedPassword = BCrypt.Net.BCrypt.HashPassword("1234");
                            string insertAdmin = $"INSERT INTO Users (Username, Password) VALUES ('admin', '{hashedPassword}')";
                            using (SQLiteCommand insertCmd = new SQLiteCommand(insertAdmin, conn))
                                insertCmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static SQLiteConnection GetConnection()
        {
            return new SQLiteConnection(ConnectionString);
        }
    }
}
