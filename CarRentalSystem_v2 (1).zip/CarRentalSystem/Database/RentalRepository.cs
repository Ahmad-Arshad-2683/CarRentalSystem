using System.Data.SQLite;
using CarRentalSystem.Models;

namespace CarRentalSystem.Database
{
    public class RentalRepository
    {
        public static List<Rental> GetAll()
        {
            List<Rental> list = new List<Rental>();
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("SELECT * FROM Rentals", conn))
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            list.Add(new Rental
                            {
                                Id           = reader.GetInt32(0),
                                CustomerName = reader.GetString(1),
                                CarNumber    = reader.GetString(2),
                                StartDate    = reader.GetString(3),
                                EndDate      = reader.GetString(4),
                                Total        = reader.GetDouble(5)
                            });
                    }
                }
            }
            catch { }
            return list;
        }

        public static bool Add(Rental r)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "INSERT INTO Rentals (CustomerName, CarNumber, StartDate, EndDate, Total) VALUES (@c, @cn, @s, @e, @t)";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@c",  r.CustomerName);
                        cmd.Parameters.AddWithValue("@cn", r.CarNumber);
                        cmd.Parameters.AddWithValue("@s",  r.StartDate);
                        cmd.Parameters.AddWithValue("@e",  r.EndDate);
                        cmd.Parameters.AddWithValue("@t",  r.Total);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Update(Rental r)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string sql = "UPDATE Rentals SET CustomerName=@c, CarNumber=@cn, StartDate=@s, EndDate=@e, Total=@t WHERE Id=@id";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@c",  r.CustomerName);
                        cmd.Parameters.AddWithValue("@cn", r.CarNumber);
                        cmd.Parameters.AddWithValue("@s",  r.StartDate);
                        cmd.Parameters.AddWithValue("@e",  r.EndDate);
                        cmd.Parameters.AddWithValue("@t",  r.Total);
                        cmd.Parameters.AddWithValue("@id", r.Id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }

        public static bool Delete(int id)
        {
            try
            {
                using (SQLiteConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Rentals WHERE Id=@id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch { return false; }
        }
    }
}
