namespace CarRentalSystem.Models
{
    public class Customer
    {
        public int    Id           { get; set; }
        public string CustomerName { get; set; } = "";
        public string PhoneNumber  { get; set; } = "";
        public string Address      { get; set; } = "";
    }

    public class Car
    {
        public int    Id        { get; set; }
        public string CarName   { get; set; } = "";
        public double RentPrice { get; set; }
        public string CarNumber { get; set; } = "";
    }

    public class Rental
    {
        public int    Id           { get; set; }
        public string CustomerName { get; set; } = "";
        public string CarNumber    { get; set; } = "";
        public string StartDate    { get; set; } = "";
        public string EndDate      { get; set; } = "";
        public double Total        { get; set; }
    }
}
